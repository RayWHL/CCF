//ͨ������
//���ܼ򵥲����Ƿ����ͨ·��������һ��ͨ��ʱ��˵������ͬ������

#include <iostream>
#include <vector>

using namespace std;

int n, m;

struct edge
{
	int to;
	edge *next;
};

struct node
{
	int i;
	int color;
	edge *next;
};

node input[1000];
int middle[1000][1000];


void addedge(int from, int to)
{
	edge *newedge = (edge*)malloc(sizeof(edge));
	newedge->to = to - 1;
	newedge->next = input[from - 1].next;
	input[from - 1].next = newedge;
}

void dfs(int k)
{
	input[k].color = 1;
	for (edge *p = input[k].next; p; p = p->next)
	{
		if (input[p->to].color == 0)
			dfs(p->to);
	}
	input[k].color = 2;
}

int dfsvisit()
{
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			input[j].color = 0;
		}
		dfs(i);
		for (int j = 0; j < n; ++j)
		{
			if (input[j].color == 2)
			{
				middle[i][j] = 1;
				middle[j][i] = 1;
			}
		}

	}
	return 0;
}

int main()
{
	int a, b;
	cin >> n >> m;
	for (int i = 0; i < m; ++i)
	{
		cin >> a >> b;
		addedge(a, b);
	}
	//cout << dfsvisit() << endl;
	dfsvisit();
	int out = 0;
	for (int i = 0; i < n; ++i)
	{
		int flag = 0;
		for (int j = 0; j < n; ++j)
		{
			if (middle[i][j] == 0)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 0) ++out;
	}
	cout << out << endl;
	return 0;
}
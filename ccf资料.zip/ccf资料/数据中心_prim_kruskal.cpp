  /*kruskal AC*/
#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;

struct  edge
{
	int from;  //��0��ʼ
	int to;
	int d;
	bool operator <(const edge temp) const
	{
		return d < temp.d;
	}
};

edge Edge[100000];  //edge��0��ʼ
int FS[50000];		//fs��0��ʼ
int n, m, root;

int FindSet(int n)
{
	if (FS[n] == n)
		return n;
	else
		return FS[n]= FindSet(FS[n]);  //���ڼ���
}

void unionset(int n1, int n2)
{
	FS[n2] = n1;
}

void kruskal()
{
	int i;
	int node = 0;
	for (i = 0; i < m; ++i)
	{
		int f1 = FindSet(Edge[i].from);
		int f2 = FindSet(Edge[i].to);
		if (f1 != f2)
		{
			++node;
			unionset(f1, f2);
			if (node == n - 1)
			{
				cout << Edge[i].d;
				return;
			}
		}
	}
}

int main()
{
	int a, b, c;
	cin >> n >> m >> root;
	//scanf("%d %d %d",&n,&m,&root);
	for (int i = 0; i < m; ++i)
	{
		//����ͼ����������
		cin >> a >> b >> c;
		Edge[i].from = a - 1;
		Edge[i].to = b - 1;
		Edge[i].d = c;
		
	}
	for (int i = 0; i < n; ++i)
	{
		FS[i] = i;
	}
	sort(Edge, Edge+m);
	kruskal();
	return 0;
}

/* PRIM AC*/  //����kruskal
#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>
#include <set>
#include <queue>
#include <functional>

using namespace std;

struct  edge
{
	int d;
	int to;

	edge *next;
};

bool operator >(edge a, edge b)
{
	return a.d > b.d;
}

struct node
{
	int i;
	edge *next;
};

node NODE[500001];
int n, m, root;
set <int> node_deal;    //������ĵ�
priority_queue <edge, vector<edge>, greater<edge>> q;  //��С���ȶ���

void addedge(int a, int b, int c)
{
	edge *temp = new edge;
	temp->to = b;
	temp->d = c;
	temp->next = NODE[a].next;
	NODE[a].next = temp;
}

void prim()
{
	int out = 0;
	int no = 0;
	edge *temp, e1;
	temp = NODE[root-1].next;
	node_deal.insert(root-1);
	for (; temp; temp = temp->next)
	{
		q.push(*temp);
	}
	while (!q.empty())
	{
		e1 = q.top();
		q.pop();
		if (node_deal.find(e1.to) == node_deal.end())
		{
			++no;
			node_deal.insert(e1.to);
			if (e1.d > out)
				out = e1.d;
			if (no == n - 1)
			{
				printf("%d", out);
				return;
			}
			for (temp = NODE[e1.to].next; temp; temp = temp->next)
			{
				q.push(*temp);
			}
		}
	}
}

int main()
{
	cin >> n >> m >> root;
	int a, b, c;
	//��ʼ��
	for (int i = 0; i < n; ++i) 
	{
		NODE[i].i = i;
		NODE[i].next = NULL;
	}
	for (int i = 0; i < m; ++i)
	{
		//scanf("%d %d %d", &(a), &(b), &(c));
		cin >> a >> b >> c;
		addedge(a-1, b-1, c);
		addedge(b-1, a-1, c);
		//cin >> Edge[i].from >> Edge[i].to >> Edge[i].d;
	}
	prim();

	return 0;
}

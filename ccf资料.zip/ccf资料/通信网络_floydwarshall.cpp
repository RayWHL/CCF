//ͨ������
//���ܼ򵥲����Ƿ����ͨ·��������һ��ͨ��ʱ��˵������ͬ������

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int max_int = 0x3f3f3f3f;

int n, m;

int d[1000][1000];
int dk[1000][1000];

void floyd_warshall()
{
	for (int k = 0; k < n; ++k)
	{
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				dk[i][j] = min(d[i][j], d[i][k] + d[k][j]);
			}
		}
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
				d[i][j] = dk[i][j];
		}
	}
}

int main()
{
	int a, b;
	cin >> n >> m;
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			d[i][j] = max_int;
		}
	}
	for (int i = 0; i < n; ++i)
		d[i][i] = 0;
	for (int i = 0; i < m; ++i)
	{
		cin >> a >> b;
		d[a-1][b-1] = 1;
	}
	floyd_warshall();
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			if (d[i][j] < max_int)
				d[j][i] = 0;
		}
	}
	int out = 0;
	for (int i = 0; i < n; ++i)
	{
		int flag = 0;
		for (int j = 0; j < n; ++j)
		{
			if (d[i][j] >= max_int)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 0) ++out;
	}
	cout << out << endl;
	return 0;
}
#include <iostream>
#include <set>
#include <vector>
#include <algorithm>

using namespace std;

struct edge
{
	int to;
	bool operator < (const edge temp) const
	{
		return to < temp.to;
	}
};

struct node
{
	int i;
	set<edge> Edge;
};

node input_node[10000];
char visit[10000][10000];
int out[100001];
int n, m;

void addedge(int a, int b)
{
	edge *e1 = (edge *)malloc(sizeof(edge));
	e1->to = b;
	input_node[a].Edge.insert(*e1);

	edge *e2 = (edge *)malloc(sizeof(edge));
	e2->to = a;
	input_node[b].Edge.insert(*e2);

}

int dfs(int i,int k)
{
	int flag = 0;
	set<edge>::iterator it;
	for (it = input_node[i].Edge.begin(); it != input_node[i].Edge.end(); ++it)
	{
		if(visit[i][it->to]==1)
			continue;
		flag = 1;
		visit[i][it->to] = 1;
		visit[it->to][i] = 1;
		if (dfs(it->to, k + 1) == 1)
		{
			out[k] = i;
			if (k == m - 1)
				out[m] = it->to;
			return 1;
		}
		visit[i][it->to] = 0;
		visit[it->to][i] = 0;

	}
	if (flag == 0 && k == m)
		return 1;
	else return 0;
}

int dfsvisit()
{
	for (int i = 0; i < n; ++i)
	{
		if (dfs(i, 0) == 1)
		{
			for (int j = 0; j < m; ++j)
			{
				cout << out[j] + 1 << " ";
			}
			cout<<out[m]+1 << endl;
			return 1;
		}
	}
	cout << -1 << endl;
	return 0;
}

int main()
{
	int a, b;
	cin >> n >> m;
	for (int i = 0; i < m; ++i)
	{
		cin >> a >> b;
		addedge(a - 1, b - 1);
	}
	dfsvisit();
	return 0;
}

